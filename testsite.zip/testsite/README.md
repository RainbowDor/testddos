first step - sudo apt-get install python-scapy
second step - pip install scapy[basic]